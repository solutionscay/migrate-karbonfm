KarbonFM demo file: placeholder site photos.
